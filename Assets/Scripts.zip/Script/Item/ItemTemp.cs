using UnityEngine;

public class ItemTemp : MonoBehaviour
{
    public int itemNo;
    /// <summary>
    /// ���ׂ�
    /// </summary>
    public string inversText;
    /// <summary>
    /// �擾
    /// </summary>
    public string acquirText;
    /// <summary>
    /// �s��
    /// </summary>
    public string actionText;

    /// <summary>
    /// ���ׂ�
    /// </summary>
    public virtual void Invers() { }

    /// <summary>
    /// �擾
    /// </summary>
    /// <returns></returns>
    public virtual int Acquir() { return 0; }

    /// <summary>
    /// �s��
    /// </summary>
    public virtual void Action(int i) { }

    public virtual void ChangerSet() { }
}
