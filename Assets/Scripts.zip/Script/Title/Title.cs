using Unity.Mathematics;
using UnityEditor;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

/// <summary>
/// �^�C�g���V�[���̊Ǘ�
/// </summary>
public class Title : MonoBehaviour
{
    [SerializeField, Header("OptionObject")] GameObject option;
    [SerializeField, Header("�ǂݍ��݂����V�[��")] private string gameScene;
    [SerializeField, Header("PlayerInput")] PlayerInput input;
    [SerializeField, Header("Animator")] Animator anima;
    int command = 3;
    GameManager gameManager;
    [SerializeField, Header("BGM�̉���")] Slider bgmVolume;
    [SerializeField, Header("SE�̉���")] Slider seVolume;

    [SerializeField, Header("BGM�̉��ʐ�")] Text bgmText;
    [SerializeField, Header("SE�̉��ʐ�")] Text seText;

    private void Start()
    {
        AnimeD();
        option.SetActive(false);
        gameManager = FindAnyObjectByType<GameManager>();
    }

    public void AnimeD()
    {
        input.SwitchCurrentActionMap("Option");
        input.currentActionMap.Disable();
        input.SwitchCurrentActionMap("Title");
        input.currentActionMap.Disable();
    }
    public void AnimeE()
    {
        input.ActivateInput();
        switch (command)
        {
            case 0: //�Q�[���X�^�[�g
                return;
            case 1: //�I�v�V�������J��
                input.SwitchCurrentActionMap("Title");
                input.currentActionMap.Disable();
                input.SwitchCurrentActionMap("Option");
                input.currentActionMap.Enable();
                break;
            case 2: //�Q�[������߂�
                return;
            case 3: //�I�v�V���������
                input.SwitchCurrentActionMap("Option");
                input.currentActionMap.Disable();
                input.SwitchCurrentActionMap("Title");
                input.currentActionMap.Enable();
                break;
            default:
                Debug.LogError("������");
                break;

        }
    }

    public void AnimeC()
    {
        switch (command)
        {
            case 0: //�Q�[���X�^�[�g
                
                SceneManager.LoadScene(gameScene);
                return;

            case 1: //�I�v�V�������J��
                option.SetActive(true);
                var values = gameManager.GetValues();

                bgmVolume.value = values.x * 1000;
                seVolume.value = values.y * 1000;
                bgmText.text = $"{bgmVolume.value * 0.1f:F1}%";
                seText.text = $"{seVolume.value * 0.1f:F1}%";
                break;

            case 2: //�Q�[������߂�
#if UNITY_EDITOR
                UnityEditor.EditorApplication.isPlaying = false;//�Q�[���J����
#else
        Application.Quit();//�Q�[���J����
#endif
                return;

            case 3: //�I�v�V���������
                option.SetActive(false);
                break;

            default:
                Debug.LogError("������");
                break;
        }
        anima.Play("Title_0");
    }

    //----------Title----------
    /// <summary> GameStart </summary>
    public void OnStart() { Operation(0); }
    /// <summary> OpenOption </summary>
    public void OnOption() { Operation(1); }
    /// <summary> QuitGame </summary>
    public void OnQuit() { Operation(2); }

    //----------Option----------
    /// <summary> �ύX��K�p </summary>
    public void OnApply()
    {
        gameManager.SetValues(true, bgmVolume.value, seVolume.value);
        Operation(3);
    }
    /// <summary> �ύX��j�� </summary>
    public void OnCancel()
    {
        gameManager.SetValues(false);
        Operation(3);
    }

    /// <summary> �؂�ւ� </summary>
    /// <param name="id"></param>
    void Operation(int id)
    {
        command = id;
        anima.Play("Title_1");
    }

    private void FixedUpdate()
    {
        if(input.currentActionMap.name == "Option")
        {
            var volume = new float2(input.actions["BGM"].ReadValue<float>(), input.actions["SE"].ReadValue<float>());
            bgmVolume.value += volume.x;
            seVolume.value += volume.y;

            bgmText.text = $"{bgmVolume.value * 0.1f:F1}%";
            seText.text = $"{seVolume.value * 0.1f:F1}%";

            gameManager.Confirmation(bgmVolume.value, seVolume.value, volume.y != 0);
        }
    }

    public void SeUp()
    {
        gameManager.Confirmation(bgmVolume.value, seVolume.value, true);
    }


}
