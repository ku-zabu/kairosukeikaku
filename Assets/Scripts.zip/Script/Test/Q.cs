/*
using UnityEditor;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Q : MonoBehaviour
{
    [SerializeField] GameObject Stagebutoon;
    [SerializeField] GameObject Option;
    [SerializeField, Header("�ǂݍ��݂����V�[��")] private SceneAsset gameScene;

    public void OnButtonClicked(int stageNumber)
    {
        if (Stagebutoon == null || Option == null) return;
        {
            Stagebutoon.SetActive(stageNumber == 1);
            Option.SetActive(stageNumber == 2);
        }
    }
         public void SceneLoad()
    {
        SceneManager.LoadScene(gameScene.name);
    }

    

}
*/

