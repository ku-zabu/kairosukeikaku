using UnityEngine;

using UnityEngine.AI;

public class EnemyController : MonoBehaviour
{
    public GameObject target;
    private NavMeshAgent agent;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        agent=GetComponent<NavMeshAgent>();
    }

    // Update is called once per frame
    void Update()
    {
        if(target)
        {
            agent.destination = target.transform.position;
        }
    }
}
