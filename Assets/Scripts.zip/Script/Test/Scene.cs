using UnityEngine;
using UnityEngine.SceneManagement;

public class Scene : MonoBehaviour
{

    [SerializeField] private string _loadScene; //�V�[�������L�q

    public void SceneChange()
    {
        SceneManager.LoadScene(_loadScene);
    }

}